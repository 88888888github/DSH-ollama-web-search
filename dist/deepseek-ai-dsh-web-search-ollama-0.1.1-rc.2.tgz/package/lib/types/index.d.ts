/**
 * Register an Ollama-backed provider in `ctx.web` and pin the seam's search
 * selection to it while this package's settings section is enabled and its API
 * key is configured. Whenever Ollama is not active (or the plugin unloads) the
 * seam returns to exactly the deployment's own selection, captured at attach.
 * @module @deepseek-ai/dsh-web-search-ollama
 */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
export { OllamaSearchProvider, OLLAMA_API_KEY_REF, OLLAMA_DEFAULT_ENDPOINT, OLLAMA_HELPER_SCRIPT, OLLAMA_HELPER_TIMEOUT_MS, OLLAMA_KEY_REJECTED_HINT, OLLAMA_PROXY_HINT, dispatchOllamaSearch, mapOllamaResponse, } from './provider.ts';
export type { OllamaHelperVerdict, OllamaSearchProviderOptions, SubprocessSpawnFace, } from './provider.ts';
/** Cordis plugin name used by loader diagnostics. */
export declare const name = "web-search-ollama";
/** The web seam this provider registers into. */
export declare const inject: string[];
/** Settings namespace carrying this provider's enable switch and proxy. */
export declare const WEB_SEARCH_OLLAMA_SETTINGS_NAMESPACE: import("@deepseek-ai/dsh-settings").SettingsNamespace;
/** Plugin config (all optional — `apply` fills schema defaults). */
export interface Config {
    /** Route web_search through Ollama while a key is configured. Defaults to true. */
    enabled?: boolean;
    /** Optional HTTP(S) proxy for the search helper, e.g. http://127.0.0.1:7890. */
    proxy?: string;
}
export declare const Config: z<Config>;
/**
 * Register the Ollama search provider with `ctx.web` and pin the seam's
 * selection to it while the section is enabled and a key is configured.
 */
export declare function apply(ctx: Context, config: Config): void;
//# sourceMappingURL=index.d.ts.map