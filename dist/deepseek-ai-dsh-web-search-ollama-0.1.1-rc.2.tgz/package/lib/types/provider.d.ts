/**
 * Ollama web search through `POST https://ollama.com/api/web_search` with Bearer auth.
 *
 * HTTP goes through a one-shot node helper spawned on the subprocess service
 * rather than this process's own fetch: the optional proxy is a per-request
 * fact, and routing it through process environment would leak into every other
 * fetch in the harness (including LLM traffic). The helper receives only this
 * request's proxy entries, so the isolation is exact.
 * @module @deepseek-ai/dsh-web-search-ollama/provider
 */
import type { WebSearchProvider, WebSearchRequest, WebSearchResult } from '@deepseek-ai/dsh-web';
import type { SubprocessHandle, SubprocessSpawnSpec } from '@deepseek-ai/dsh-subprocess';
/** Stable id this provider registers under. */
export declare const OLLAMA_PROVIDER_ID = "ollama";
/** Credential reference holding the Ollama API key. Fixed rather than configurable: one reference addresses the whole capability. */
export declare const OLLAMA_API_KEY_REF = "OLLAMA_API_KEY";
/** The public Ollama web search endpoint (fixed: the API has one). */
export declare const OLLAMA_DEFAULT_ENDPOINT = "https://ollama.com/api/web_search";
/** Helper backstop, kept below the deployment's 60s web_search tool budget. */
export declare const OLLAMA_HELPER_TIMEOUT_MS = 55000;
/** Hint attached to network-failure diagnostics. */
export declare const OLLAMA_PROXY_HINT = "If this machine cannot reach ollama.com directly, fill in a local proxy URL (for example http://127.0.0.1:7890) in the ollama web search settings card and retry.";
/** Hint attached to rejected-key diagnostics. */
export declare const OLLAMA_KEY_REJECTED_HINT = "The key was rejected; rebuild it at ollama.com/settings/keys.";
/** The subprocess surface this package uses; structural so tests can script it. */
export interface SubprocessSpawnFace {
    resolveExecutable(command: string): Promise<string>;
    spawn(spec: SubprocessSpawnSpec): SubprocessHandle;
}
/** Resolved provider options (the plugin's `apply` supplies section and credential defaults). */
export interface OllamaSearchProviderOptions {
    /**
     * Whether this provider may serve searches right now: the section enabled AND a key configured. The cheap local check
     * behind available() — a switched-off or unkeyed provider must drop out of auto-selection rather than make it ambiguous.
     */
    readonly active: boolean;
    /** The section's proxy for this operation, empty for a direct connection. */
    readonly proxy: string;
    /** Resolve the current Ollama API key for one search operation. */
    readonly resolveApiKey: () => Promise<string | undefined>;
    /** Run one search request end to end (helper HTTP + mapping); supplied by the plugin, which owns the subprocess service. */
    readonly dispatch: (input: {
        readonly key: string;
        readonly proxy: string;
    }, request: WebSearchRequest, signal?: AbortSignal) => Promise<WebSearchResult>;
}
/** The Ollama-backed search provider; every failure surfaces as {@link WebError}. */
export declare class OllamaSearchProvider implements WebSearchProvider {
    private readonly resolveOptions;
    readonly id = "ollama";
    /**
     * @param resolveOptions - the options for the NEXT operation, snapshotted
     * once at each operation's entry so one search never mixes two sections. A
     * thunk rather than a value because the plugin's settings section can change
     * between searches, and re-registering the provider to carry new state would
     * make the seam's selection observable to the user as a flicker.
     */
    constructor(resolveOptions: () => OllamaSearchProviderOptions);
    available(): boolean;
    search(request: WebSearchRequest, signal?: AbortSignal): Promise<WebSearchResult>;
}
/** The verdict the helper writes to stdout. */
export interface OllamaHelperVerdict {
    readonly ok?: boolean;
    readonly status?: number;
    readonly body?: unknown;
    readonly error?: string;
}
/**
 * One-shot helper script: read one request from stdin, POST it with Bearer
 * auth, and emit a JSON verdict. Runs in its own node process so the optional
 * proxy environment (HTTPS_PROXY/HTTP_PROXY, honored by Node's fetch) applies
 * to exactly this request and nothing else.
 */
export declare const OLLAMA_HELPER_SCRIPT = "let buf='';process.stdin.setEncoding('utf8');process.stdin.on('data',(c)=>{buf+=c});process.stdin.on('end',async()=>{const emit=(o)=>{try{process.stdout.write(JSON.stringify(o))}catch(e){}};try{const req=JSON.parse(buf);const res=await fetch(req.url,{method:'POST',headers:{authorization:'Bearer '+req.key,'content-type':'application/json',accept:'application/json','user-agent':'deepseek-harness-ollama-search/1.0'},body:JSON.stringify({query:req.query,max_results:req.maxResults}),signal:AbortSignal.timeout(req.timeoutMs)});const text=await res.text();let body;try{body=JSON.parse(text)}catch(e){body=undefined}emit({ok:res.ok,status:res.status,body:body!==undefined?body:{raw:String(text).slice(0,2000)}});}catch(e){emit({ok:false,error:String((e&&e.message)||e)})}});";
/**
 * Map one Ollama response body to a normalized search result. Items without a
 * usable url are skipped; `content` becomes the snippet. The web service owns
 * the final maxResults truncation, so truncated is always false here.
 * @param body - the parsed response body (or its raw-string fallback).
 * @returns the normalized result.
 */
export declare function mapOllamaResponse(body: unknown): WebSearchResult;
/**
 * Run one search through the helper and map its verdict. The subprocess face
 * is passed in rather than injected so this step stays testable without a live
 * process tree.
 * @param subprocess - the spawn face (the service or a scripted double).
 * @param input - the resolved key and the section's proxy for this request.
 * @param request - the query and optional result limit.
 * @param signal - cancellation; starts the helper's terminate escalation.
 * @returns the mapped result.
 */
export declare function dispatchOllamaSearch(subprocess: SubprocessSpawnFace, input: {
    readonly key: string;
    readonly proxy: string;
}, request: WebSearchRequest, signal?: AbortSignal): Promise<WebSearchResult>;
//# sourceMappingURL=provider.d.ts.map